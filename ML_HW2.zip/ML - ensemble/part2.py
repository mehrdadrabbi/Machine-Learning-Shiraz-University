from sklearn.ensemble import RandomForestClassifier
import numpy

# Load Data into Matrices
train_x = numpy.loadtxt(open('X_train.csv', 'rb'), delimiter=',', skiprows=1)
train_y = numpy.loadtxt(open('y_train.csv', 'rb'), delimiter=',', skiprows=1)

test_x = numpy.loadtxt(open('X_test.csv', 'rb'), delimiter=',', skiprows=1)

# Cross Validation on Random Forest
num_folds = 10
subset_size = len(train_x)/num_folds
accs = [0] * num_folds
for i in range(num_folds):
    test_fold_x = train_x[i*subset_size:][:subset_size]
    test_fold_y = train_y[i*subset_size:][:subset_size]
    train_fold_x = numpy.concatenate((train_x[:i*subset_size], train_x[(i+1)*subset_size:]), axis=0)
    train_fold_y = numpy.concatenate((train_y[:i*subset_size], train_y[(i+1)*subset_size:]), axis=0)

    # Configure Random Forest Classifier
    forest = RandomForestClassifier(n_estimators=100, criterion='gini', max_depth=None)

    # Train The Model
    forest = forest.fit(train_fold_x, train_fold_y)

    # Test The Model
    output = forest.predict(test_fold_x)
    accs[i] = 1.0*sum(output == test_fold_y)/len(output)

print 'Total Accuracy is:',
print 1.0*sum(accs)/num_folds

# Produce Label for Test File
# Configure Random Forest Classifier
forest = RandomForestClassifier(n_estimators=100, criterion='gini', max_depth=None)

# Train The Model
forest = forest.fit(train_fold_x, train_fold_y)

# Test The Model
output = forest.predict(test_fold_x)
output = output.astype(int)
print output
numpy.savetxt("result2.csv", output, fmt='%i', delimiter=',')
